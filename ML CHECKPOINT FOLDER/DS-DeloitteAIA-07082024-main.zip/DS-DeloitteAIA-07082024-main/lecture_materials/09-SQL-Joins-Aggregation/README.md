# SQL Joins and Aggregation

Materials:
- [Jupyter Notebook: SQL](sql.ipynb)

## Learning Goals

- Use SQL aggregation functions with GROUP BY
- Use HAVING for group filtering
- Use SQL JOIN to combine tables using keys