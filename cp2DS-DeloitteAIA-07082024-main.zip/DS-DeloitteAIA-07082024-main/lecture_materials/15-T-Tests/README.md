# T-Tests

Introduces hypothesis testing that leads to discussing the normal curve and z-test. 

## Learning Goals

- Understand how type 1 & type 2 errors can be made in hypothesis tests
- Perform a Student's t-test and interpret the results
